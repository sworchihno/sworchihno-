**Syed Amiya Protham Omi**

Founder of Sworchihno Ltd. A visionary innovator from Bangladesh.