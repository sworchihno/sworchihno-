# Sworchihno Ltd

Visionary tech company founded by Syed Amiya Protham Omi.